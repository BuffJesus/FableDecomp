#!/usr/bin/env python3
"""fable_core -- bpy-FREE data layer for the Fable: TLC Blender import addon.

This module contains ALL the parse -> convert logic and NONE of the Blender
(`bpy`) calls, so it can be unit-tested standalone (see tests/test_core.py) and
reviewed independently of the Blender layer. The bpy operator layer
(`import_op.py`) consumes the plain-data structures produced here.

It CONSUMES the project readers READ-ONLY (never modifies them):
  * tools/parse_bigb.py      -- BIGB container walker
  * tools/parse_mesh.py      -- MBANK mesh descriptor / submesh / skeleton
  * tools/parse_texture.py   -- 34-byte texture Info descriptor + DXT/ARGB decoders
  * tools/lionhead_lz.py     -- LZO1X decompressor (recovered from the engine)

What this layer produces from a graphics.big (+ its texture banks):
  * ImageData      -- real decoded RGBA pixel arrays (LZO1X-decompress + DXT/ARGB)
  * MaterialData   -- material -> base-texture binding (the headline feature)
  * BoneData       -- skeleton bone NAMES recovered from the compiled payload
  * SubmeshData / LodData / MeshModel -- LOD + submesh + bounds tree
  * decode_geometry() -- STUB hook, returns None pending docs/BIG_MESH_GEOMETRY.md

Everything above (materials/textures, bone names, submesh tree) is decodable
TODAY. Geometry (verts/faces/UVs) is honestly stubbed -- see decode_geometry().
"""
from __future__ import annotations

import os
import sys
import struct
from dataclasses import dataclass, field
from typing import Optional

# ---------------------------------------------------------------------------
# Import the project readers read-only. They live in tools/ (two levels up from
# this file: tools/blender_addon/io_scene_fable/fable_core.py -> tools/).
# We add tools/ to sys.path so `import parse_bigb` etc. resolve exactly as the
# readers expect (parse_mesh/parse_texture themselves `import parse_bigb`).
# ---------------------------------------------------------------------------
_THIS_DIR = os.path.dirname(os.path.abspath(__file__))
_TOOLS_DIR = os.path.normpath(os.path.join(_THIS_DIR, "..", ".."))


def _ensure_tools_on_path(tools_dir: Optional[str] = None) -> str:
    """Put the tools/ dir on sys.path so the read-only readers import.

    Returns the tools dir actually used. Callers (e.g. the bpy operator, which
    may be installed to a copied location that is NOT inside the repo) can pass
    an explicit tools_dir; otherwise the sibling repo layout is assumed.
    """
    td = tools_dir or _TOOLS_DIR
    if td not in sys.path:
        sys.path.insert(0, td)
    return td


# Lazily imported reader module handles (populated by _load_readers()).
parse_bigb = None
parse_mesh = None
parse_texture = None
lionhead_lz = None


def _load_readers(tools_dir: Optional[str] = None):
    """Import (once) the four read-only reader modules. Raises ImportError with
    an actionable message if the tools/ dir cannot be located."""
    global parse_bigb, parse_mesh, parse_texture, lionhead_lz
    if parse_bigb is not None:
        return
    td = _ensure_tools_on_path(tools_dir)
    try:
        import parse_bigb as _pb
        import parse_mesh as _pm
        import parse_texture as _pt
        import lionhead_lz as _lz
    except ImportError as ex:  # pragma: no cover - environment dependent
        raise ImportError(
            "fable_core could not import the FableTLC readers from %r. "
            "Set the 'Tools dir' in the import options to the repo's tools/ "
            "folder (containing parse_bigb.py, parse_mesh.py, parse_texture.py, "
            "lionhead_lz.py). Original error: %s" % (td, ex))
    parse_bigb, parse_mesh, parse_texture, lionhead_lz = _pb, _pm, _pt, _lz


# ===========================================================================
# Plain data structures (bpy-free). These are the contract with the bpy layer.
# ===========================================================================
@dataclass
class ImageData:
    """A decoded texture, ready to hand to bpy.data.images."""
    tex_id: int
    name: str
    width: int              # real (authored) image dimensions
    height: int
    alloc_width: int        # allocated (padded, pow2) surface dims
    alloc_height: int
    fmt_name: str           # "DXT1" / "DXT3" / "A8R8G8B8"
    # RGBA float pixels flattened bottom-row-first (Blender's image.pixels order),
    # length == alloc_width*alloc_height*4, each in [0,1]. See rgba_to_blender().
    pixels: list = field(default_factory=list, repr=False)
    source_tga: str = ""    # original build .tga path (from the entry Dep)

    @property
    def pixel_count(self) -> int:
        return self.alloc_width * self.alloc_height


@dataclass
class MaterialData:
    slot: int                       # material index within the mesh
    name: str                       # e.g. "MESH_FOO_mat0"
    base_tex_id: int                # textures.big entry ID of the base texture
    base_tex_name: str = ""         # resolved texture entry name (if found)
    image: Optional[ImageData] = None  # decoded base texture (None if undecodable)


@dataclass
class BoneData:
    name: str
    index: int
    parent: int = -1                # -1 = root; parenting is a heuristic (see notes)
    # Real bone transforms await the geometry RE. head/tail are placeholder.
    head: tuple = (0.0, 0.0, 0.0)
    tail: tuple = (0.0, 0.1, 0.0)


@dataclass
class SubmeshData:
    lod: int
    index: int
    n_verts: int
    n_faces: int
    svert: int                      # vertex-format class code {4,6,20,22}
    material_slot: int = -1         # best-effort binding to a MaterialData slot
    geometry: Optional["GeometryData"] = None  # filled by decode_geometry when available


@dataclass
class LodData:
    index: int
    offset: int                     # payload byte offset to the LOD block
    switch_distance: float = 0.0
    submeshes: list = field(default_factory=list)  # list[SubmeshData]


@dataclass
class GeometryData:
    """Actual mesh geometry -- currently always None (stubbed). When
    docs/BIG_MESH_GEOMETRY.md lands, decode_geometry() fills these."""
    vertices: list = field(default_factory=list)   # list[(x,y,z)]
    faces: list = field(default_factory=list)       # list[(i,j,k)]
    uvs: list = field(default_factory=list)         # per-loop [(u,v), ...]


@dataclass
class MeshModel:
    """The whole importable model recovered from one MBANK compiled-mesh entry."""
    name: str
    entry_id: int
    entry_type: int
    has_skeleton: bool
    origin: tuple                   # the 10-float bound/pivot block (opaque)
    materials: list = field(default_factory=list)   # list[MaterialData]
    bones: list = field(default_factory=list)        # list[BoneData]
    lods: list = field(default_factory=list)         # list[LodData]
    warnings: list = field(default_factory=list)

    @property
    def bounds_center(self) -> tuple:
        """Best-effort AABB center from the origin block (first 3 floats are a
        plausible pivot/min; kept purely for placing the placeholder empties)."""
        o = self.origin
        return (o[0], o[1], o[2]) if len(o) >= 3 else (0.0, 0.0, 0.0)


# ===========================================================================
# Texture bank index + decode
# ===========================================================================
class TextureBank:
    """Loads one or more GBANK .big files (textures.big / frontend.big) and
    resolves + decodes texture entries by ID.

    A mesh material's `matTexId` is a textures.big ENTRY ID, so we index every
    texture entry by id across all supplied banks and decode on demand.
    """

    def __init__(self, bank_paths, tools_dir: Optional[str] = None):
        _load_readers(tools_dir)
        self._by_id = {}            # id -> (buf, subname, entry)
        self._cache = {}            # id -> ImageData (decoded, memoized)
        for path in bank_paths:
            if path and os.path.isfile(path):
                self._index_bank(path)

    def _index_bank(self, path):
        with open(path, "rb") as f:
            b = f.read()
        _, _, fo, _ = parse_bigb.parse_header(b)
        subs, _ = parse_bigb.parse_footer(b, fo)
        for s in subs:
            entries, _, _, err = parse_bigb.parse_toc(b, s, fo)
            # Texture IDs are per-SUBBANK, and both GBANK_GUI_PC and GBANK_MAIN_PC
            # start their IDs at 1 -> they COLLIDE. A mesh's matTexId resolves to
            # the world/character bank GBANK_MAIN_PC (validated: seagull ids 5,6 =
            # SEAGULL_BODY/WING in MAIN, not the EDITORGUI icons in GUI). So MAIN
            # entries OVERRIDE GUI entries for a colliding id; GUI/frontend only
            # fill ids MAIN doesn't define.
            is_main = "MAIN" in s["name"].upper()
            for e in entries:
                cur = self._by_id.get(e["id"])
                if cur is None:
                    self._by_id[e["id"]] = (b, s["name"], e, is_main)
                elif is_main and not cur[3]:
                    self._by_id[e["id"]] = (b, s["name"], e, is_main)

    def has(self, tex_id: int) -> bool:
        return tex_id in self._by_id

    def entry_name(self, tex_id: int) -> str:
        rec = self._by_id.get(tex_id)
        return rec[2]["name"] if rec else ""

    def entry_subbank(self, tex_id: int) -> str:
        rec = self._by_id.get(tex_id)
        return rec[1] if rec else ""

    def count(self) -> int:
        return len(self._by_id)

    def decode(self, tex_id: int) -> Optional[ImageData]:
        """Decode a texture entry to an ImageData (LZO1X-decompress the base mip,
        then DXT/ARGB decode to RGBA). Memoized. Returns None if not decodable."""
        if tex_id in self._cache:
            return self._cache[tex_id]
        rec = self._by_id.get(tex_id)
        if not rec:
            return None
        buf, subname, e, _is_main = rec
        img = self._decode_entry(buf, e)
        self._cache[tex_id] = img
        return img

    def _decode_entry(self, buf, e) -> Optional[ImageData]:
        if e["infosize"] < 34 or e["size"] == 0:
            return None
        info = parse_texture.parse_info(e["info"])
        if not info:
            return None
        fmt = info["fmt"]
        if fmt not in parse_texture.FORMATS:
            return None
        pay = buf[e["offset"]:e["offset"] + e["size"]]

        # --- read the base (largest) mip block: u16/u32 clen prefix (framing) ---
        try:
            clen, hdr = parse_texture.payload_block_header(pay, 0)
        except Exception:
            return None
        comp = pay[hdr:hdr + clen]
        aw, ah = info["alloc_w"], info["alloc_h"]

        # expected raw byte size of the base mip (linear DXT / ARGB)
        raw_len = _base_mip_raw_len(fmt, aw, ah)
        try:
            raw = lionhead_lz.decompress(comp, raw_len)
        except Exception:
            return None
        # engine encoder emits the base mip up to 3 bytes short -> pad with zero
        if len(raw) < raw_len:
            raw = raw + b"\x00" * (raw_len - len(raw))
        elif len(raw) > raw_len:
            raw = raw[:raw_len]

        # --- decode linear pixels to RGBA (uint8 HxWx4) via parse_texture ---
        try:
            rgba = parse_texture.decode_mip(fmt, raw, aw, ah)
        except Exception:
            return None

        pixels = rgba_to_blender(rgba)
        dep = e["deps"][-1] if e.get("deps") else ""
        return ImageData(
            tex_id=e["id"], name=e["name"], width=info["width"], height=info["height"],
            alloc_width=aw, alloc_height=ah, fmt_name=info["fmt_name"],
            pixels=pixels, source_tga=dep,
        )


def _base_mip_raw_len(fmt: int, aw: int, ah: int) -> int:
    """Raw (uncompressed) byte length of the base mip for a linear surface."""
    name, unit, compressed = parse_texture.FORMATS[fmt]
    if compressed:  # DXT: `unit` bytes per 4x4 block
        bx = (aw + 3) // 4
        by = (ah + 3) // 4
        return bx * by * unit
    # A8R8G8B8: 4 bytes/pixel (unit here is bpp=32)
    return aw * ah * 4


def rgba_to_blender(rgba) -> list:
    """Convert a uint8 HxWx4 RGBA array (row 0 = top) to Blender's flat pixel
    list: float [0,1], RGBA, row-major with the BOTTOM row first (Blender stores
    images bottom-up). Uses numpy if present, else a pure-Python fallback."""
    try:
        import numpy as np
        arr = np.asarray(rgba, dtype=np.float32) / 255.0
        arr = arr[::-1]                       # flip vertically (bottom row first)
        return arr.reshape(-1).tolist()
    except Exception:
        h = len(rgba)
        out = []
        for y in range(h - 1, -1, -1):
            for px in rgba[y]:
                out.append(px[0] / 255.0)
                out.append(px[1] / 255.0)
                out.append(px[2] / 255.0)
                out.append(px[3] / 255.0)
        return out


# ===========================================================================
# Mesh (MBANK) model extraction -- descriptor + skeleton + submesh tree
# ===========================================================================
# 3ds-Max Biped bone-name tokens (per docs/BIG_MESH_FORMAT.md section 3).
# Full Biped bone-name tokens that appear (possibly with an L/R side prefix and
# a trailing digit) in the skeleton string block. Used to anchor extraction.
_BONE_ANCHORS = (
    "Scene Root", "Bip01", "Pelvis", "Spine", "Neck", "Head", "Ponytail",
    "Clavicle", "UpperArm", "Forearm", "Hand", "Finger", "Thigh", "Calf",
    "Foot", "Toe", "Tail", "Footsteps", "Wing", "Jaw", "Ear",
)

_PRINTABLE = set(range(32, 127))


def _clean_token(payload: bytes, pos: int, tok: str) -> str:
    """Given a match of anchor `tok` starting at byte `pos`, expand left over a
    small optional side/prefix ('L '/'R ') and right over a trailing digit, then
    return a clean printable bone name. Bounded so interleaved binary (the region
    is compressed, so names are partly framed by control bytes) can't leak in."""
    start = pos
    # extend left by up to 3 printable chars to catch a 'L '/'R ' side prefix
    j = pos - 1
    left = 0
    while j >= 0 and left < 3 and payload[j] in _PRINTABLE and chr(payload[j]) not in "\x00":
        # only absorb a side letter+space pattern, not arbitrary text
        if chr(payload[j]) in "LR" and pos - j <= 2:
            start = j
        j -= 1
        left += 1
    end = pos + len(tok)
    # extend right over a single trailing digit (e.g. 'Bip01', 'Toe0')
    if end < len(payload) and 48 <= payload[end] <= 57:
        end += 1
    raw = payload[start:end]
    s = "".join(chr(c) for c in raw if c in _PRINTABLE).strip()
    return s


def recover_bone_names(payload: bytes, header_end: int, first_lod_off: int) -> list:
    """Recover the skeleton bone NAMES from the compiled-mesh payload.

    The skeleton is a 3ds-Max Biped bone-name string hierarchy embedded between
    the header and the first LOD block (docs/BIG_MESH_FORMAT.md section 3). That
    region is INTERLEAVED with binary (bone matrices) and is partly framed by the
    BBB control-byte compression, so the names are NOT cleanly NUL-terminated --
    some are truncated ('Forearm'->'For', 'Calf'->'alf'). We therefore recover
    names by anchoring on the known Biped token set and extracting a bounded,
    printable-only window around each hit, in file order.

    This is HONEST PARTIAL recovery: it yields the Biped bone names that survive
    the compression framing, in order, so an armature with the right bone labels
    can be built. Real bone TRANSFORMS (head/tail matrices) and the exact parent
    hierarchy await the mesh-geometry RE (docs/BIG_MESH_GEOMETRY.md); parenting
    here is a flat 'everything under Scene Root' placeholder.
    """
    lo = max(0, header_end)
    hi = first_lod_off if first_lod_off and first_lod_off > lo else len(payload)
    region = payload[lo:hi]

    hits = []  # (position, name)
    for tok in _BONE_ANCHORS:
        tb = tok.encode("latin1")
        start = 0
        while True:
            p = region.find(tb, start)
            if p < 0:
                break
            name = _clean_token(region, p, tok)
            if name:
                hits.append((p, name))
            start = p + 1
    hits.sort(key=lambda x: x[0])

    names = []
    seen = set()
    for _pos, nm in hits:
        if nm not in seen:
            seen.add(nm)
            names.append(nm)

    bones = []
    for idx, nm in enumerate(names):
        # 'Scene Root' is the root; everything else chains under it (placeholder).
        parent = -1 if (idx == 0 or nm == "Scene Root") else 0
        bones.append(BoneData(name=nm, index=idx, parent=parent))
    return bones


def decode_geometry(payload: bytes, submesh, lod_off: int) -> Optional[GeometryData]:
    """GEOMETRY STUB -- returns None today.

    The packed vertex buffer and the compressed (Big Blue Box control-byte) index
    stream inside each LOD/SUBM block are IDENTIFIED but NOT byte-decoded yet; per
    docs/BIG_MESH_FORMAT.md section 6 this needs the engine's mesh decompressor
    (a Ghidra target held by a separate agent). When docs/BIG_MESH_GEOMETRY.md
    and its decoder land, fill THIS function body to return a GeometryData with:
        vertices : list[(x,y,z)]   dequantized from the packed coords (sVert class)
        faces    : list[(i,j,k)]   from the decompressed index stream
        uvs      : per-loop [(u,v)] from the s11e4 tu/tv fields
    The call site in build_model()/the bpy layer already wires this in, so ONLY
    this body needs implementing later -- nothing else changes.

    Inputs available for the future implementation:
      payload  -- the full compiled-mesh payload bytes
      submesh  -- a SubmeshData (has n_verts, n_faces, svert)
      lod_off  -- byte offset of the enclosing LOD block
    """
    # TODO(geometry): implement once docs/BIG_MESH_GEOMETRY.md exists.
    return None


def _resolve_material_names(mats, tex_bank: Optional[TextureBank]):
    for m in mats:
        if tex_bank and tex_bank.has(m.base_tex_id):
            m.base_tex_name = tex_bank.entry_name(m.base_tex_id)


def build_model(buf: bytes, entry, tex_bank: Optional[TextureBank] = None,
                decode_textures: bool = True, tools_dir: Optional[str] = None) -> MeshModel:
    """Build a MeshModel from one MBANK compiled-mesh TOC entry.

    buf       -- the full graphics.big bytes
    entry     -- a parse_bigb TOC entry dict (type in {1,2,4,5}, compiled-mesh)
    tex_bank  -- optional TextureBank for material name resolution + decoding
    """
    _load_readers(tools_dir)
    pay = buf[entry["offset"]:entry["offset"] + entry["size"]]
    warnings = []

    desc = parse_mesh.parse_mesh_descriptor(entry["info"], pay, entry["name"])
    if desc is None:
        # Fall back to a descriptor-less parse (rare degenerate meshes).
        desc = parse_mesh.parse_mesh_descriptor(entry["info"])
    if desc is None:
        warnings.append("mesh descriptor did not parse zero-leftover; "
                        "materials/LODs unavailable for this entry")
        return MeshModel(name=entry["name"], entry_id=entry["id"],
                         entry_type=entry["type"], has_skeleton=False,
                         origin=(0.0,) * 10, warnings=warnings)

    # --- payload header (name, skeleton flag, 10-float origin) ---
    try:
        hdr = parse_mesh.parse_compiled_header(pay)
        has_skel = bool(hdr["skel_flag"])
        origin = hdr["origin"]
        header_end = hdr["header_end"]
    except Exception:
        has_skel = False
        origin = desc["origin"]
        header_end = 0

    # --- materials (matTexId -> base texture) ---
    materials = []
    for slot, tid in enumerate(desc["matTexId"]):
        md = MaterialData(slot=slot, name="%s_mat%d" % (entry["name"], slot),
                          base_tex_id=tid)
        materials.append(md)
    _resolve_material_names(materials, tex_bank)
    if decode_textures and tex_bank is not None:
        for md in materials:
            md.image = tex_bank.decode(md.base_tex_id)

    # --- skeleton bone names ---
    bones = []
    if has_skel:
        first_lod = desc["lod"][0] if desc["lod"] else 0
        bones = recover_bone_names(pay, header_end, first_lod)
        if not bones:
            warnings.append("skeleton flag set but no Biped bone names recovered")

    # --- LOD + submesh tree ---
    lods = []
    lod_dists = desc.get("lod_dist", []) or []
    for li, loff in enumerate(desc["lod"]):
        lod = LodData(index=li, offset=loff,
                      switch_distance=(lod_dists[li] if li < len(lod_dists) else 0.0))
        # Only LOD0's block start is precisely known (lod[0] = byte offset). For
        # deeper LODs the descriptor stores sizes, not offsets, so we scan from
        # lod[0] for LOD0 and leave deeper LODs as structural placeholders unless
        # a submesh scan finds headers. We surface LOD0 submeshes concretely.
        if li == 0:
            subms = parse_mesh.find_subm_headers(pay, loff)
            for si, sm in enumerate(subms):
                sd = SubmeshData(lod=li, index=si, n_verts=sm["nVerts"],
                                 n_faces=sm["nFaces"], svert=sm["sVert"],
                                 material_slot=(si if si < len(materials) else -1))
                # geometry stub hook (returns None today)
                sd.geometry = decode_geometry(pay, sd, loff)
                lod.submeshes.append(sd)
        lods.append(lod)

    return MeshModel(name=entry["name"], entry_id=entry["id"],
                     entry_type=entry["type"], has_skeleton=has_skel,
                     origin=tuple(origin), materials=materials, bones=bones,
                     lods=lods, warnings=warnings)


# ===========================================================================
# Top-level convenience: open a graphics.big, list/import compiled meshes
# ===========================================================================
def open_graphics_big(path: str, tools_dir: Optional[str] = None):
    """Return (buf, [compiled-mesh entries]) from a graphics.big. Compiled meshes
    are entry types {1,2,4,5} whose payload begins with 'MESH_'."""
    _load_readers(tools_dir)
    with open(path, "rb") as f:
        b = f.read()
    magic, _, fo, _ = parse_bigb.parse_header(b)
    if magic != b"BIGB":
        raise ValueError("%s is not a BIGB container" % path)
    subs, _ = parse_bigb.parse_footer(b, fo)
    meshes = []
    for s in subs:
        entries, _, _, err = parse_bigb.parse_toc(b, s, fo)
        for e in entries:
            if e["type"] in parse_mesh.MESH_TYPES:
                if parse_mesh.classify_payload(b, e) == "compiled-mesh":
                    e["sub"] = s["name"]
                    meshes.append(e)
    return b, meshes


def guess_texture_banks(graphics_big_path: str) -> list:
    """Given a graphics.big path, guess the sibling texture bank paths
    (textures.big + frontend.big) under the standard install layout:
        <data>/graphics/graphics.big
        <data>/graphics/pc/textures.big
        <data>/graphics/pc/frontend.big
    Returns the ones that exist."""
    gdir = os.path.dirname(os.path.abspath(graphics_big_path))
    candidates = [
        os.path.join(gdir, "pc", "textures.big"),
        os.path.join(gdir, "pc", "frontend.big"),
        os.path.join(gdir, "textures.big"),
        os.path.join(gdir, "frontend.big"),
    ]
    return [c for c in candidates if os.path.isfile(c)]


def find_entry(buf, meshes, name_or_id):
    """Locate a compiled-mesh entry by exact name or by numeric id."""
    try:
        want_id = int(name_or_id)
    except (TypeError, ValueError):
        want_id = None
    for e in meshes:
        if want_id is not None and e["id"] == want_id:
            return e
        if e["name"] == name_or_id:
            return e
    return None
